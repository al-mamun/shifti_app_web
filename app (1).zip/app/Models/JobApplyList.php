<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobApplyList extends Model
{
    protected $table = 'job_apply_list';
    public $timestamp = true;
   
}
